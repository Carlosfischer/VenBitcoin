$(document).ready(function(){

	$('#clave2').keyup(function(){
		var pass1= $('#clave1').val();
		var pass2= $('#clave2').val();

	if( clave1 == clave2){
		$('#error1').text("Coinciden!").css("color", "green");
	}else{

		$('#error1').text("No Coinciden").css("color", "red");
	}

	if( pass2 == ""){
		$('#error1').text("Espacio en blanco").css("color", "white");
			
	}	

	});


});
